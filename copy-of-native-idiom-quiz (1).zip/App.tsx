import React, { useState, useEffect, useCallback } from 'react';
import { GameState, QuizQuestion, UserAnswer } from './types';
import { fetchIdiomsQuiz } from './services/geminiService';
import SplashScreen from './components/SplashScreen';
import QuizCard from './components/QuizCard';
import ResultsScreen from './components/ResultsScreen';
import ProgressBar from './components/ProgressBar';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.Ready);
  const [quizData, setQuizData] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<UserAnswer[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const shuffleArray = <T,>(array: T[]): T[] => {
    return [...array].sort(() => Math.random() - 0.5);
  };
  
  const loadQuiz = useCallback(async () => {
    setGameState(GameState.Loading);
    setError(null);
    setUserAnswers([]);
    setCurrentQuestionIndex(0);

    try {
      const idioms = await fetchIdiomsQuiz();
      if (idioms.length === 0) {
        throw new Error("Failed to generate idioms. Please try again.");
      }
      const formattedQuizData = idioms.map(item => ({
        ...item,
        options: shuffleArray([...item.distractors, item.meaning]),
        correctAnswer: item.meaning,
      }));
      setQuizData(formattedQuizData);
      setGameState(GameState.Quiz);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setGameState(GameState.Error);
    }
  }, []);

  const handleStartQuiz = () => {
    loadQuiz();
  };
  
  const handleRestart = () => {
    setGameState(GameState.Ready);
    setQuizData([]);
    setUserAnswers([]);
    setCurrentQuestionIndex(0);
    setError(null);
  }

  const handleAnswerSelect = (selectedAnswer: string) => {
    const isCorrect = quizData[currentQuestionIndex].correctAnswer.english === selectedAnswer;
    const newUserAnswer: UserAnswer = {
      questionIndex: currentQuestionIndex,
      selectedAnswer,
      isCorrect,
    };
    setUserAnswers(prev => [...prev, newUserAnswer]);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setGameState(GameState.Results);
    }
  };

  const renderContent = () => {
    switch (gameState) {
      case GameState.Loading:
        return <SplashScreen isLoading={true} onStart={() => {}} />;
      case GameState.Quiz:
        if (!quizData[currentQuestionIndex]) return null;
        return (
          <div className="w-full max-w-2xl mx-auto">
            <ProgressBar current={currentQuestionIndex + 1} total={quizData.length} />
            <QuizCard
              key={currentQuestionIndex}
              question={quizData[currentQuestionIndex]}
              onAnswerSelect={handleAnswerSelect}
              onNext={handleNextQuestion}
              questionNumber={currentQuestionIndex + 1}
              totalQuestions={quizData.length}
            />
          </div>
        );
      case GameState.Results:
        return <ResultsScreen userAnswers={userAnswers} quizData={quizData} onRestart={handleRestart} />;
      case GameState.Error:
         return (
            <div className="text-center p-8">
              <h2 className="text-2xl font-bold text-red-500 mb-4">Oops! Something went wrong.</h2>
              <p className="text-slate-400 mb-6">{error}</p>
              <button
                onClick={handleRestart}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
              >
                Try Again
              </button>
            </div>
          );
      case GameState.Ready:
      default:
        return <SplashScreen isLoading={false} onStart={handleStartQuiz} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 font-sans">
       <header className="w-full max-w-2xl mx-auto text-center mb-4 sm:mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600 leading-tight">
          Native Idiom Quiz
          <span className="block text-2xl sm:text-3xl font-bold text-indigo-300 mt-1">원어민 이디엄 퀴즈</span>
        </h1>
        <p className="text-slate-400 mt-2">
          30 daily idioms only native speakers know<br/>
          <span className="text-slate-500">원어민만 아는 30개 관용어</span>
        </p>
      </header>
      <main className="w-full flex-grow flex items-center justify-center">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;