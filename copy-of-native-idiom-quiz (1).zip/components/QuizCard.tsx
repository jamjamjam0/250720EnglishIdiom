import React, { useState, useEffect } from 'react';
import { QuizQuestion, AnswerOption } from '../types';
import { CheckIcon, XIcon } from './icons';

interface QuizCardProps {
  question: QuizQuestion;
  onAnswerSelect: (selectedAnswer: string) => void;
  onNext: () => void;
  questionNumber: number;
  totalQuestions: number;
}

const QuizCard: React.FC<QuizCardProps> = ({ question, onAnswerSelect, onNext, questionNumber, totalQuestions }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  
  useEffect(() => {
    setSelectedAnswer(null);
    setIsAnswered(false);
  }, [question]);

  const handleOptionClick = (option: AnswerOption) => {
    if (isAnswered) return;
    setSelectedAnswer(option.english);
    onAnswerSelect(option.english);
    setIsAnswered(true);
  };

  const getButtonClass = (option: AnswerOption) => {
    if (!isAnswered) {
      return 'bg-slate-700 hover:bg-slate-600';
    }
    if (option.english === question.correctAnswer.english) {
      return 'bg-green-600/90 border-green-400';
    }
    if (option.english === selectedAnswer) {
      return 'bg-red-600/90 border-red-400';
    }
    return 'bg-slate-700 opacity-60';
  };
  
  const getIcon = (option: AnswerOption) => {
    if (!isAnswered) return null;
    if (option.english === question.correctAnswer.english) {
        return <CheckIcon className="h-6 w-6 text-white" />;
    }
    if (option.english === selectedAnswer) {
        return <XIcon className="h-6 w-6 text-white" />;
    }
    return null;
  }

  return (
    <div className="bg-slate-800 p-6 sm:p-8 rounded-2xl shadow-2xl w-full border border-slate-700">
      <div className="mb-6 text-center">
        <p className="text-sm font-medium text-indigo-400 mb-2">IDIOM</p>
        <h2 className="text-2xl sm:text-3xl font-bold text-white flex items-center justify-center gap-x-3">
            <span className="text-4xl">{question.emoji}</span>
            <span>"{question.idiom}"</span>
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-6">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleOptionClick(option)}
            disabled={isAnswered}
            className={`w-full p-4 rounded-lg text-left transition-all duration-300 border-2 border-transparent ${getButtonClass(option)}`}
          >
            <div className="flex items-center justify-between">
                <div className="flex items-center flex-1 min-w-0">
                    <span className="text-3xl mr-3 sm:mr-4">{option.emoji}</span>
                    <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-100 truncate">{option.english}</p>
                        <p className="text-sm text-slate-400 mt-1 truncate">{option.korean}</p>
                    </div>
                </div>
                <div className="ml-4 flex-shrink-0">
                    {getIcon(option)}
                </div>
            </div>
          </button>
        ))}
      </div>
      
      {isAnswered && (
         <div className="bg-slate-900/50 p-4 rounded-lg mt-6 text-center">
            <p className="font-bold text-lg mb-2 text-white">Example:</p>
            <p className="text-slate-300 italic">"{question.example.english}"</p>
            <p className="text-slate-400 mt-1">"{question.example.korean}"</p>
         </div>
      )}

      {isAnswered && (
        <div className="mt-6 text-center">
          <button
            onClick={onNext}
            className="w-full max-w-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors transform hover:scale-105"
          >
            {questionNumber === totalQuestions ? 'See Results' : 'Next Question'}
          </button>
        </div>
      )}
    </div>
  );
};

export default QuizCard;