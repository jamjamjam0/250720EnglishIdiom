import React from 'react';
import { UserAnswer, QuizQuestion } from '../types';
import { CheckIcon, XIcon } from './icons';

interface ResultsScreenProps {
  userAnswers: UserAnswer[];
  quizData: QuizQuestion[];
  onRestart: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ userAnswers, quizData, onRestart }) => {
  const correctAnswersCount = userAnswers.filter(answer => answer.isCorrect).length;
  const totalQuestions = quizData.length;
  const scorePercentage = Math.round((correctAnswersCount / totalQuestions) * 100);

  const getScoreColor = () => {
    if (scorePercentage >= 80) return 'text-green-400';
    if (scorePercentage >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 border border-slate-700">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Quiz Complete!</h2>
        <p className="text-slate-300 text-lg">Here's how you did:</p>
        <p className={`text-6xl font-extrabold my-4 ${getScoreColor()}`}>
          {correctAnswersCount}<span className="text-3xl text-slate-400">/{totalQuestions}</span>
        </p>
      </div>

      <div className="space-y-4 mb-8 max-h-96 overflow-y-auto pr-2">
        {quizData.map((question, index) => {
          const userAnswer = userAnswers.find(ua => ua.questionIndex === index);
          if (!userAnswer) return null;
          return (
            <div key={index} className="bg-slate-900/70 p-4 rounded-lg">
              <p className="font-bold text-white mb-2 flex items-center gap-x-2">
                  <span className="text-xl">{question.emoji}</span>
                  <span>{index + 1}. {question.idiom}</span>
              </p>
              <div className="flex items-start space-x-3 pl-2">
                {userAnswer.isCorrect ? (
                  <CheckIcon className="h-6 w-6 text-green-500 flex-shrink-0 mt-1" />
                ) : (
                  <XIcon className="h-6 w-6 text-red-500 flex-shrink-0 mt-1" />
                )}
                <div className="text-sm">
                  <p className="text-slate-300">
                    <span className="font-semibold">Your answer:</span> {userAnswer.selectedAnswer}
                  </p>
                  {!userAnswer.isCorrect && (
                    <p className="text-slate-300 mt-1">
                      <span className="font-semibold text-green-400">Correct answer:</span> {question.correctAnswer.english}
                      <span className="text-slate-400"> ({question.correctAnswer.korean})</span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-center">
        <button
          onClick={onRestart}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition-colors transform hover:scale-105"
        >
          Try a New Set
        </button>
      </div>
    </div>
  );
};

export default ResultsScreen;
