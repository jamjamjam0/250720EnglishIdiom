import React from 'react';

interface SplashScreenProps {
  isLoading: boolean;
  onStart: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ isLoading, onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 bg-slate-800 rounded-2xl shadow-2xl max-w-lg mx-auto border border-slate-700">
      <h2 className="text-3xl font-bold text-white mb-4 leading-tight">
        <span className="block">Welcome to the Idiom Challenge!</span>
        <span className="text-2xl text-indigo-300 mt-1 block">원어민 이디엄 챌린지</span>
      </h2>
      <p className="text-slate-300 mb-8 max-w-md">
        Test your skills with 30 tricky idioms only native speakers know. A new set is available every day.
        <br />
        <span className="text-slate-400">매일 새로운 30개의 원어민 관용어 퀴즈로 당신의 실력을 확인해보세요.</span>
      </p>
      <button
        onClick={onStart}
        disabled={isLoading}
        className="w-full max-w-xs bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-bold py-4 px-8 rounded-lg text-lg transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg flex items-center justify-center"
      >
        {isLoading ? (
          <>
             <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating Quiz...
          </>
        ) : (
          'Start Daily Quiz'
        )}
      </button>
    </div>
  );
};

export default SplashScreen;