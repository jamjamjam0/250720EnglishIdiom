import { GoogleGenAI, Type } from "@google/genai";
import { IdiomData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const answerOptionSchema = {
    type: Type.OBJECT,
    properties: {
        english: { type: Type.STRING, description: "The meaning in English." },
        korean: { type: Type.STRING, description: "The meaning translated into Korean." },
        emoji: { type: Type.STRING, description: "A single, cute emoji that visually relates to this specific option."}
    },
    required: ["english", "korean", "emoji"]
};

const exampleSentenceSchema = {
    type: Type.OBJECT,
    properties: {
        english: { type: Type.STRING, description: "The example sentence in English." },
        korean: { type: Type.STRING, description: "The example sentence translated into Korean." }
    },
    required: ["english", "korean"]
};


const schema = {
  type: Type.OBJECT,
  properties: {
    idioms: {
      type: Type.ARRAY,
      description: "An array of 30 English idioms for a quiz.",
      items: {
        type: Type.OBJECT,
        properties: {
          idiom: {
            type: Type.STRING,
            description: "The idiom phrase."
          },
          emoji: {
              type: Type.STRING,
              description: "A single, cute, relevant emoji for the idiom."
          },
          meaning: {
            ...answerOptionSchema,
            description: "The correct meaning of the idiom, including English, Korean, and a relevant emoji."
          },
          example: {
            ...exampleSentenceSchema,
            description: "An example sentence using the idiom correctly, provided in both English and Korean."
          },
          distractors: {
            type: Type.ARRAY,
            description: "An array of three incorrect but plausible meanings, each with English, Korean, and a related emoji.",
            items: answerOptionSchema,
          }
        },
        required: ["idiom", "emoji", "meaning", "example", "distractors"]
      }
    }
  },
  required: ["idioms"]
};


export const fetchIdiomsQuiz = async (): Promise<IdiomData[]> => {
  try {
    const prompt = `
      You are an expert linguist specializing in English idioms and Korean translation. Your task is to generate content for a flashcard quiz app.
      Please provide exactly 30 idioms that are commonly known by native English speakers but are often confusing for non-native learners.

      For each of the 30 idioms, provide:
      1. The idiom itself.
      2. A single, cute, relevant emoji that visually represents the idiom.
      3. The correct, concise meaning. This meaning should include the English text, a natural Korean translation, and its own relevant emoji.
      4. An example sentence that clearly demonstrates the idiom's usage, provided in both English and a natural Korean translation.
      5. Three incorrect but plausible-sounding definitions to be used as distractors. Each distractor must also be provided with its English text, Korean translation, and its own unique, relevant emoji. The emojis for the distractors should be clever and relate to the incorrect meaning to make the quiz challenging.

      Return the data in the specified JSON format. Do not include any idioms that are too simple, offensive, or overly archaic. Focus on idioms used in modern, everyday conversation.
      Example idioms: 'bite the bullet', 'spill the beans', 'break a leg', 'hit the road'.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonText = response.text.trim();
    const parsedData = JSON.parse(jsonText);

    if (!parsedData.idioms || !Array.isArray(parsedData.idioms)) {
        throw new Error("Invalid data structure received from API.");
    }
    
    // Additional validation to ensure distractors array has 3 items
    const validatedIdioms = parsedData.idioms.filter((idiom: any) => idiom.distractors && idiom.distractors.length === 3);
    if(validatedIdioms.length !== parsedData.idioms.length) {
        console.warn("Some idioms were filtered out due to incorrect number of distractors.");
    }
    if (validatedIdioms.length === 0) {
        throw new Error("API returned idioms with an incorrect number of distractors.");
    }


    return validatedIdioms as IdiomData[];
  } catch (error) {
    console.error("Error fetching idiom quiz from Gemini:", error);
    throw new Error("Failed to fetch data from the Gemini API. Please check your connection and API key.");
  }
};