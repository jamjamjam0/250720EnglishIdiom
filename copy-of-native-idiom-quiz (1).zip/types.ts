export enum GameState {
  Ready = 'ready',
  Loading = 'loading',
  Quiz = 'quiz',
  Results = 'results',
  Error = 'error',
}

export interface AnswerOption {
  english: string;
  korean: string;
  emoji: string;
}

export interface ExampleSentence {
    english: string;
    korean: string;
}

export interface IdiomData {
  idiom: string;
  emoji: string;
  meaning: AnswerOption;
  example: ExampleSentence;
  distractors: AnswerOption[];
}

export interface QuizQuestion extends IdiomData {
  options: AnswerOption[];
  correctAnswer: AnswerOption;
}

export interface UserAnswer {
  questionIndex: number;
  selectedAnswer: string; // The English text of the selected answer
  isCorrect: boolean;
}